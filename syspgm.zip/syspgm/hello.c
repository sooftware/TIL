#include <stdio.h>

void main(){
	printf("노답들\n");
}	
