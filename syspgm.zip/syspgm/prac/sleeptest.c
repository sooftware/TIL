#include <stdio.h>
#include <unistd.h>

void main(){
	unsigned int s=5;
	printf("sleep = %d\n",sleep(5));
	return;
}
