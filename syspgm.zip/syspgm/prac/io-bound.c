#include <stdio.h>

void main(){
	getchar();
}
