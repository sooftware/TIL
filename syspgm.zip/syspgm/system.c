#include <stdlib.h>
int main(void) {
	system("ls -l");
	system("pidof bash");
	return 0;
}

