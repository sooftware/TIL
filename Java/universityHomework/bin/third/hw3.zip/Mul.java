package third;

import java.util.Scanner;

public class Mul {
	int a,b;
	Scanner sc = new Scanner(System.in);
	
	public void setValue(int a,int b){
		this.a=a;
		this.b=b;
	}

	public int calculate(int a,int b){
		int result=0;
		
		result=a*b;
		
		return result;
	}
}
