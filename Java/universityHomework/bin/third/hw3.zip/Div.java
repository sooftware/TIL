package third;

import java.util.Scanner;

public class Div {
	int a, b;
	Scanner sc = new Scanner(System.in);

	public void setValue(int a, int b) {
		this.a = a;
		this.b = b;
	}

	public int calculate(int a, int b) {
		int result = 0;

		if (b == 0) {
			System.out.println("## 0���δ� ���� �� �����ϴ�!!!");
		} else {
			result = a / b;
		}

		return result;
	}
}
