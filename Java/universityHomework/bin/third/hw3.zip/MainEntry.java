package third;

import java.util.Scanner;

public class MainEntry {
	public static void main(String[] args) {
		int a=0,b=0;
		char mode='0';
		Scanner sc = new Scanner(System.in);
		String modeInput;
		
		System.out.print("## ù��° ���ڸ� �Է����ּ��� : ");
		a=sc.nextInt();
		System.out.print("## �ι�° ���ڸ� �Է����ּ��� : ");
		b=sc.nextInt();
		do{
			System.out.print("## (+) : ���ϱ� (-) : ���� (*) : ���ϱ� (/) : ������ ");
			modeInput=sc.next();
			mode=modeInput.charAt(0);
		}while(mode != '+' && mode != '-' && mode != '*' && mode != '/');
		
		operate(a,b,mode);
	}

	public static void operate(int a, int b, char mode) {
		int result = 0;

		if (mode == '+') {
			Add add = new Add();
			result = add.calculate(a, b);
			display(result);
		} else if (mode == '-') {
			Sub sub = new Sub();
			result = sub.calculate(a, b);
			display(result);
		} else if (mode == '*') {
			Mul mul = new Mul();
			result = mul.calculate(a, b);
			display(result);
		} else if (mode == '/') {
			Div div = new Div();
			result = div.calculate(a, b);
			if (!(b == 0)) {
				display(result);
			}
		}

		return;
	}

	public static void display(int result) {
		System.out.println("## ���� ����� " + result + "�Դϴ�.");
	}
}
