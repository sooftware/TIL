package fourth;

public class Add extends Calc{
	int a=0,b=0;
	@Override
	public void setValue(int a, int b) {
		// TODO Auto-generated method stub
		this.a=a;
		this.b=b;
	}

	@Override
	public int calculate(int a, int b) {
		// TODO Auto-generated method stub
		int result=0;
		
		result=a+b;
		
		return result;
	}
}
