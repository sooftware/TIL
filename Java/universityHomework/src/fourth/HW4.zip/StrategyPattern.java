package fourth;

public class StrategyPattern extends Calc{
	Calc cal;
	int a=0,b=0;
	
	@Override
	public void setValue(int a, int b) {
		// TODO Auto-generated method stub
		cal.setValue(a, b);
	}

	
	@Override
	public int calculate(int a, int b) {
		// TODO Auto-generated method stub
		int result=0;
		
		result=cal.calculate(a, b);
		
		return result;
	}

	public void setCal(Calc cal) {
		this.cal = cal;
	}	
}
