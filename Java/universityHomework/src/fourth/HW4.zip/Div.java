package fourth;

public class Div extends Calc{
	int a=0,b=0;

	@Override
	public void setValue(int a, int b) {
		// TODO Auto-generated method stub
		this.a=a;
		this.b=b;
	}

	@Override
	public int calculate(int a, int b) {
		// TODO Auto-generated method stub
		int result = 0;

		if (b == 0) {
			System.out.println("0���δ� ���� �� �����ϴ�!!!");
		} else {
			result = a / b;
		}

		return result;
	}
}
