package fourth;

public abstract class Calc {
	public Calc(){
		
	}
	
	public abstract  void setValue(int a,int b);
	public abstract  int calculate(int a,int b);
}
