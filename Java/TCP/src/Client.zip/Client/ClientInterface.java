package Client;

public interface ClientInterface {
	public static final int SERVER_PORT=5000;
	public static final String SERVER_IP = "10.20.7.75";
}
